var xhr;
function traerPersonas() {


}

function guardarPersona(persona) {
   
  }

function eliminarPersona(id) {
 }

function modificarPersona(persona) {

}

var btnAlta;
var divFrm;
var frmAlta;
var divInfo;
var btnCancelar;

var lista;

window.onload = asignarEventos;

function asignarEventos() {

    btnAlta = document.getElementById('btnAlta');

    btnAlta.onclick = function () {
        mostrarFormulario();
    }

        //traer las personas y mostrar en la tabla
   

}

function darAlta(e) {

}

function mostrarFormulario(persona) {

}

function setSpinner(){

}
function actualizarTabla(lista) {

}


function altaPersona() {
    //agregar el codigo que crea conveniente
  
    var nuevaPersona = new Persona(nombre, apellido, email, sexo);

     //enviar la insercion al server
}


function eliminacionPersona() {
    //agregar el codigo que crea conveniente

    var id = parseInt(document.getElementById('id').value);

     //enviar la eliminacion al server


}

function modificacionPersona(persona) {
    //agregar el codigo que crea conveniente
    var gender;
    if (document.getElementById('rdoMasculino').checked) {
        gender = document.getElementById('rdoMasculino').value;
    }
    else {
        gender = document.getElementById('rdoFemenino').value;
    }
    persona.gender = gender;


    //enviar la modificacion al server


}

function Persona(nombre,apellido,email,sexo){
    this.first_name = nombre;
    this.last_name = apellido;
    this.email = email;
    this.gender = sexo;
}




